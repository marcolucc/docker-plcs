import easymodbus.modbusClient
import time

plc1 = easymodbus.modbusClient.ModbusClient('plc1.rete', 502)

plc2 = easymodbus.modbusClient.ModbusClient('plc2.rete', 502)

plc2.connect()
plc1.connect()

while (True):
    #leggo i registri di input (level e request)
    
    try:
        #print("leggo da plc2")
        inputRegisters = plc2.read_coils(0, 1)
        #print(inputRegisters)
    except:
        print("Errore in lettura coil")

    try:
        #print("\n Richiesta: ")
        richiesta = inputRegisters[0]
    
        print(richiesta)
    except:
        print("errore lettura buffer registro")
    

    #scrivo i coil di richiesta
    #print("Scrivo su plc1")
    try:
        plc1.write_single_coil(2, richiesta)

        plc1.read_coils(2, 1)
    except:
        print("errore scrittura")
    #print("close connection")
    time.sleep(1)
    
