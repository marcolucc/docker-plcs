%TANK 1
A1 = 154 %cm^2
s12 = 0.5 %no-dim
s23 = s12
H1_max = 100 % cm
Q1_max = 100 %cm^3/s

a1 = 0.45 %no-dim
a2 = 0.25
a3 = 0.6
g = 980.665 % grav const

%TANK 3/
A3 = 154; %cm^2
s12 = 0.5; %no-dim
H3_max = 100; % cm
Q3_max = 10; %cm^3/s



